=== README ===

Creator: Jack Le
Email: jnanotek2711@gmail.com
Requires: .NET Framework 4.5, Windows 7, 8, 8.1, 10 (not tested on lower versions, it may work)

Emoji 2.0

== Description ==

This application acts as an on screen keyboard for emoji input. It was made specially for Microsoft Windows. It was created due to the lack of an emoji keyboard on Windows. The application is quite straight forward. When it starts up, user is presented with an emoji keyboard. To input a key, user can simply focus on the text he or she wants to input the keys on and click the keys on the on screen keyboard. The application will always be on top until user clicks the hide button on the bottom right corner. If this program is run on Windows 7, user will only see squares as output. This is because Windows 7 fonts do not support emoji symbols. The program still works properly and others still see the desired result.

THIS APPLICATION IS FREE!!  If you were charged to download or use, it would most likely be a fraud.

== Installation ==

To install, you can simple run the setup file or if the system has already had .NET Framework 4.5, you can just run the the Emoji.exe file.

To make the program run at startup, you can copy the Emoji.exe file to the Startup folder in the Start menu. Search Google if you still have questions about the process.

Feel free to send me emails (above mentioned) if you have any questions. (Please do not send spams to my email)